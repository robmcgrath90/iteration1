package com.example.fyp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;
import java.util.ArrayList;




public class StudyBuddyActiveGroups extends AppCompatActivity {

    private Toolbar toolbar;

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study_buddy_active_groups);

        //linking variable toolbar to the actual Toolbar
        toolbar=findViewById(R.id.Toolbar);
        setSupportActionBar(toolbar);

        //associating variable toolbar to the actual Toolbar
        toolbar=findViewById(R.id.Toolbar);
        setSupportActionBar(toolbar);


        //used for the recyclerview

        //reference https://www.youtube.com/watch?v=17NbUcEts9c
        ArrayList<StudybuddyrvItems> exampleList = new ArrayList<>();

        exampleList.add(new StudybuddyrvItems(R.drawable.ic_baseline_view_module_24, "Statistics", "Module"));
        exampleList.add(new StudybuddyrvItems(R.drawable.ic_time, "4PM", "Time"));
        exampleList.add(new StudybuddyrvItems(R.drawable.ic_date, "Monday 30th November", "Date"));
        exampleList.add(new StudybuddyrvItems(R.drawable.ic_blank, "", ""));
        exampleList.add(new StudybuddyrvItems(R.drawable.ic_blank, "", ""));
        exampleList.add(new StudybuddyrvItems(R.drawable.ic_baseline_view_module_24, "Accounting", "Module"));
        exampleList.add(new StudybuddyrvItems(R.drawable.ic_time, "6PM", "Time"));
        exampleList.add(new StudybuddyrvItems(R.drawable.ic_date, "Tuesday 1st December", "Date"));



        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new StudyBuddyAdpaterRV(exampleList);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);





    }
    //everything above this is in the on create method









    //*****toolbar******
    //using an infalter to show the menu items in the toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    // tutorial 2 mobile
    //https://www.youtube.com/watch?v=Pmsd2x-Bksk
    //using intents to to allow items in the menu to complete a task
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())

        {
            case R.id.delete:
                finish();
                Toast.makeText(this, "back function pressed", Toast.LENGTH_SHORT).show();
                break;
            case R.id.dropdown1:
                Intent startIntent1 = new Intent(getApplicationContext(), Jobs.class);
                startActivity(startIntent1);
                Toast.makeText(this, "dropdown1 function pressed", Toast.LENGTH_SHORT).show();
                break;
            case R.id.dropdown2:
                Intent startIntent2 = new Intent(getApplicationContext(), ClassFinder.class);
                startActivity(startIntent2);
                Toast.makeText(this, "dropdown2 function pressed", Toast.LENGTH_SHORT).show();
                break;
        }

        return super.onOptionsItemSelected(item);
    }
    //******toolbar*******


}